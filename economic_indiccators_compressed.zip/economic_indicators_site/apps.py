from django.apps import AppConfig


class EconomicIndicatorsSiteConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'economic_indicators_site'
